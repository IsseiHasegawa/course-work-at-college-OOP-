#ifndef C_STRING_UTILS_H
#define C_STRING_UTILS_H

int my_strlen(const char string[]);

#endif
