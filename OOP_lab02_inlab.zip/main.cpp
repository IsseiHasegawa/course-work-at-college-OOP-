#include "array_functions.h"
#include "Rectangle.h"
#include "c_string_utils.h"
#include <iostream>
#include <cstdlib>
#include <cstring>

int main(){
    srand(42);

    const int SIZE = 100;
    int arr[SIZE];

    fill_random(arr, SIZE);

    for (int i = 0; i < SIZE; ++i){
        std::cout << arr[i] << " ";
    }

    std::cout <<std::endl;
    std::cout << "average: " << average(arr, SIZE) << std::endl;

    const int ROW = 15;
    const int COLUMN = 15;
    char arr2D[ROW][COLUMN];

    make_puzzle(arr2D, ROW);

    std::cout << "2-D array:" << std::endl;
    print_puzzle(arr2D, ROW); 

    const int SIZEOFREC = 20;
    Rectangle rectangles[SIZEOFREC];

    // std::cout << std::endl;
    // std::cout << "Initial rectangle array" << std::endl;
    // print_rectangles(rectangles, SIZEOFREC);

    random_rectangles(rectangles, SIZEOFREC);

    std::cout << std::endl;
    std::cout << "Random rectangle array:" << std::endl;
    print_rectangles(rectangles, SIZEOFREC);

    // char example[]{ 'H', 'e', 'l', 'l', 'o', '\0' };
    char example[]{ "Hello" };

    char state[]{ "Arkansas" };
    std::cout << state << " has " << strlen(state)
            << " (logical) characters and occupies "
            << sizeof(state) << " bytes.\n";
    std::cout << state << " has " << my_strlen(state)
            << " (logical) characters and occupies "
            << sizeof(state) << " bytes.\n";

    return 0;
}
