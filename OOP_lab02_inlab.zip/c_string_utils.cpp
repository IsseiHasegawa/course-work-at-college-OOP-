#include "c_string_utils.h"

int my_strlen(const char string[]){
    int string_length = 0;
    while (string[string_length] != 0){
        ++string_length;
    }

    return string_length;
}
