#ifndef ARRAY_FUNCTON_H
#define ARRAY_FUNCTION_H
#include "Rectangle.h"

void fill_random(int array[], int sizeOfArray);
double average(int array[], int sizeOfArray);
void make_puzzle(char array2D[][15], int rows);
void print_puzzle(char array2D[][15], int rows);
void print_rectangles(Rectangle rectangles[], int sizeOfArray);
void random_rectangles(Rectangle rectangles[], int sizeOfArray);

#endif
