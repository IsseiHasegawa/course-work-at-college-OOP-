#include "array_functions.h"
#include <iostream>
#include <vector>

void fill_random(int array[], int sizeOfArray){
    for (int i = 0; i < sizeOfArray; ++i){
        array[i] = rand() % 1000 + 1;
    }
}

double average(int array[], int sizeOfArray){
    double sum = 0;
    for (int i = 0; i < sizeOfArray; ++i){
        sum += array[i];
    }
    double average = static_cast<double>(sum)/sizeOfArray;

    return average;
}

void make_puzzle(char array2D[][15], int rows){
    for (int i = 0; i < rows; ++i){
        for (int j = 0; j < 15; ++j){
            array2D[i][j] = static_cast<char>(rand() % 26 + 'a');
        }
    }
}

void print_puzzle(char array2D[][15], int rows){
    for (int i = 0; i < rows; ++i){
        for (int j = 0; j < 15; ++j){
            std::cout << array2D[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void print_rectangles(Rectangle rectangles[], int sizeOfArray){
    for (int i = 0; i < sizeOfArray; ++i){
        std::cout << (i + 1) << ": "
                  << rectangles[i].get_length() << " X "
                  << rectangles[i].get_width() << std::endl;
    }
}

void random_rectangles(Rectangle rectangles[], int sizeOfArray){
    for (int i = 0; i< sizeOfArray; ++i){
        rectangles[i].set_length(rand() % 100 + 1);
        rectangles[i].set_width(rand() % 100 + 1);
    }
}
